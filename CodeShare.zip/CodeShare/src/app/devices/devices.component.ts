import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-devices',
  templateUrl: './devices.component.html',
  styleUrls: ['./devices.component.css']
})
export class DevicesComponent implements OnInit {

  nRightClicks = 0;

  constructor() { }

  ngOnInit() {
  }

  onRightClick() {
    this.nRightClicks++;
    return false;
  }

}
