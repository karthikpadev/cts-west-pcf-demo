import { Component, OnInit, Inject, Output } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';


@Component({
  selector: 'app-column-customize',
  templateUrl: './column-customize.component.html',
  styleUrls: ['./column-customize.component.css']
})
export class ColumnCustomizeComponent implements OnInit {

  description: string = "Customize Columns";
  columnsTotal: number;
  @Output() allColumns: any[];
  
  constructor(private dialogRef: MatDialogRef<ColumnCustomizeComponent>,
    @Inject(MAT_DIALOG_DATA) data) {
      this.allColumns = data.allColumns;
      this.columnsTotal = this.allColumns.length - 2;
      this.dialogRef.updatePosition({ top: '50px', left: '350px', bottom: '0px' }).updateSize('600px', '600px');
   }

  trackByIndex(index: number, value: string) {
    return index;
  }
  save(){
    this.dialogRef.close(this.allColumns);
  }
  ngOnInit() {
  }

  toggle(col, element: HTMLInputElement) {
    this.allColumns.filter(c => { 
      if(c.name === col.name){
        c.isChecked = element.checked;
        return this.allColumns;
      } 
    });
  }
}
