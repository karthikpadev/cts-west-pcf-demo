import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ColumnCustomizeComponent } from './column-customize.component';

describe('ColumnCustomizeComponent', () => {
  let component: ColumnCustomizeComponent;
  let fixture: ComponentFixture<ColumnCustomizeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ColumnCustomizeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ColumnCustomizeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
