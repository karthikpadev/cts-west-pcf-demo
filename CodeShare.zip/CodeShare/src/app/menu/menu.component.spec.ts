import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Menu.ComponentComponent } from './menu.component.component';

describe('Menu.ComponentComponent', () => {
  let component: Menu.ComponentComponent;
  let fixture: ComponentFixture<Menu.ComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Menu.ComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Menu.ComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
