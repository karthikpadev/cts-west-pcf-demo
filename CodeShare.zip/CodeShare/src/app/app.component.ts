import { Component } from '@angular/core';
import {trigger, state, style, transition, animate} from '@angular/animations';
import { AppInventoryService } from './app-inventory/app-inventory.service';
import { AppInventoryDetailService } from './app-inventory/app-inventory-details.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [
    trigger('slideInOut', [
      state('in', style({
        transform: 'translate3d(0, 0, 0)'
      })),
      state('out', style({
        transform: 'translate3d(-120%, 0, 0)'
      })),
      transition('in => out', animate('400ms ease-in-out')),
      transition('out => in', animate('400ms ease-in-out'))
    ]),
  ],
  providers: [AppInventoryService,AppInventoryDetailService]
})
export class AppComponent {
  title = 'app';

  menuState:string = 'out';
  toggleMenu() {
    this.menuState = this.menuState === 'out' ? 'in' : 'out';
  }
}

