import { Component, OnInit, Output, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogConfig} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';

import { AppInventoryService } from './app-inventory.service';
import { IappInventory } from './app-inventory';
import { ColumnCustomizeComponent } from '../column-customize/column-customize.component';

@Component({
  selector: 'app-app-inventory',
  templateUrl: './app-inventory-mattable.component.html',
  styleUrls: ['./app-inventory.component.css']
})
export class AppInventoryComponent implements OnInit {
  
  constructor(private _appInventoryService : AppInventoryService, public dialog: MatDialog) {
  }

  pageTitle : string = "Readings";
  errorMessage: string;
  popoverContent: string[];
  appInventory : IappInventory[];  
  
  // mat table
  dataSource: MatTableDataSource<IappInventory>;
  rows= [];
  displayedColumns: string[];
  allColumns = [{ name: 'select', isChecked: true, index:0 },
               { name: 'headerId', isChecked: true, index:1 },
                { name: 'Make', isChecked: true, index:2 },
                { name: 'DeviceId', isChecked: true, index:3 },
                { name: 'Model', isChecked: true, index:4 },
                { name: 'StartTime', isChecked: true, index:5 },
                { name: 'EndTime', isChecked: true, index:6 },
                { name: 'editColumn', isChecked: true, index:7 }];

  //Pagination
  @ViewChild(MatPaginator) paginator: MatPaginator;

  /**
   * Set the paginator after the view init since this component will
   * be able to query its view for the initialized paginator.
   */
  ngAfterViewInit() {
    if(this.paginator !== undefined){
      this.dataSource.paginator = this.paginator;
    }
  }

  // Selection
  selection = new SelectionModel<IappInventory>(true, []);

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  openDialog() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    //dialogConfig.autoFocus = true;
    dialogConfig.position = {
      'top': '0',
      'left': '450'
    };
    
    dialogConfig.data = { columns: this.displayedColumns, allColumns: this.allColumns}
    let dialogRef = this.dialog.open(ColumnCustomizeComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(result => {
      this.allColumns = result;
      this.allColumns.forEach(column => this.updateDisplayedColumns(column.name, column.isChecked, column.index));
    });
  }

  updateDisplayedColumns(colName: string, colIsChecked : boolean, colIndex: number){
    const index: number = this.displayedColumns.indexOf(colName);
    
    if (index !== -1 && !colIsChecked) {
      this.displayedColumns.splice(index, 1);
    } else if (index === -1 && colIsChecked) {
      this.displayedColumns.splice(colIndex, 0, colName);
    }       
  }
  

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }
  
  // updatePopoverContent(inventory: IappInventory): any[] {
  //   return this.popoverContent = inventory.id;
    
  // }
  ngOnInit() {
    this.displayedColumns = ['select','headerId', 'Make', 'DeviceId', 'Model', 'StartTime', 'EndTime', 'editColumn'];    
    this._appInventoryService.getAppInventory1()
                .subscribe(inventory => {
                  console.log(inventory);
                  this.appInventory = inventory;
                  this.rows = this.appInventory;
                  this.dataSource = new MatTableDataSource(this.appInventory); 
                },
                  error => this.errorMessage = <any>error);
  } 
}
