import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppInventoryDetailComponent } from './app-inventory-detail.component';

describe('AppInventoryDetailComponent', () => {
  let component: AppInventoryDetailComponent;
  let fixture: ComponentFixture<AppInventoryDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppInventoryDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppInventoryDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
