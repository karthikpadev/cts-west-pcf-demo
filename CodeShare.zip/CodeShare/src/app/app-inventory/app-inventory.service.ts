import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';

import { IappInventory } from './app-inventory';

@Injectable()
export class AppInventoryService {
    private _inventoryUrl = 'http://10.252.88.252:8080/headers';
    //private _inventoryUrl = 'assets/json/appinventory.json'
    
    

    constructor(private _http: HttpClient) { 
       
    }

   getAppInventory1()/* : Observable<IappInventory[]>  */{
    
        return this._http.get<IappInventory[]>(this._inventoryUrl)
            .do(data => console.log('All: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    // getAppInventory(): IappInventory[]{
    //     return [
    //         {
    //             "inventoryId": 1,
    //             "inventoryName": "Factory Talk Activation Manager",
    //             "inventoryReputation": "Trusted",
    //             "inventoryAppType": "Service",
    //             "inventoryPublisher": "Rockwell",
    //             "inventoryDevices" : ["Device 1", "Device 2"]
    //         },
    //         {
    //             "inventoryId": 2,
    //             "inventoryName": "Factory Talk Activation Manager",
    //             "inventoryReputation": "Good",
    //             "inventoryAppType": "Startup",
    //             "inventoryPublisher": "Microsoft",
    //             "inventoryDevices" : ["Device 1", "Device 2", "Device 3", "Device 4", "Device 5" ]
    //         },
    //         {
    //             "inventoryId": 3,
    //             "inventoryName": "Rockwell RS view Enterprise",
    //             "inventoryReputation": "Unknown",
    //             "inventoryAppType": "Portable",
    //             "inventoryPublisher": "Adobe",
    //             "inventoryDevices" : ["Device 1", "Device 2", "Device 3", "Device 4", "Device 5", "Device 6", "Device 7"]
    //         },
    //         {
    //             "inventoryId": 4,
    //             "inventoryName": "Auto IT",
    //             "inventoryReputation": "Poor",
    //             "inventoryAppType": "Directory",
    //             "inventoryPublisher": "Rockwell",
    //             "inventoryDevices" : ["Device 1", "Device 2"]
    //         },
    //         {
    //             "inventoryId": 5,
    //             "inventoryName": "User or Publisher",
    //             "inventoryReputation": "NA",
    //             "inventoryAppType": "Installed",
    //             "inventoryPublisher": "Adobe",
    //             "inventoryDevices" : ["Device 1", "Device 2", "Device 3"]
    //         }
    //     ];
    // }
    private handleError(err: HttpErrorResponse) {
        // in a real world app, we may send the server to some remote logging infrastructure
        // instead of just logging it to the console
        let errorMessage = '';
        if (err.error instanceof Error) {
            // A client-side or network error occurred. Handle it accordingly.
            errorMessage = `An error occurred: ${err.error.message}`;
        } else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
        }
        console.error(errorMessage);
        return Observable.throw(errorMessage);
    }
}
