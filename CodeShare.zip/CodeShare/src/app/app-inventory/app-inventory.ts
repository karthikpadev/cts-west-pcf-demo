export interface IappInventory {
    // inventoryDevices: Array<string>;
    headerId: string;
    make: string;
    deviceId: string;
    model: string;
    startTime: string;
    endTime: string;
}