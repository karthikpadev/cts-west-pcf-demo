import { Component, OnInit, Output, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogConfig} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';

import { AppInventoryDetailService } from './app-inventory-details.service';
import { IappInventoryDetail } from './app-inventory-detail';
import { ColumnCustomizeComponent } from '../column-customize/column-customize.component';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-inventory-detail',
  templateUrl: './app-inventory-detail.component.html',
  styleUrls: ['./app-inventory-detail.component.css']
})

export class AppInventoryDetailComponent implements OnInit {
  param:string;
  constructor(private route: ActivatedRoute,private _appInventoryService : AppInventoryDetailService, public dialog: MatDialog) {
    this.param=this.route.snapshot.paramMap.get('id');
 
    console.log('detail copmponent'+this.route.snapshot.paramMap.get('id'));
  }


  pageTitle : string = "Reading Details";
  errorMessage: string;
  popoverContent: string[];
  appInventory : IappInventoryDetail[];  
  
  
  // mat table
  dataSource: MatTableDataSource<IappInventoryDetail>;
  rows= [];
  displayedColumns: string[];
  allColumns = [{ name: 'select', isChecked: true, index:0 },
                { name: 'trendId', isChecked: true, index:1 },
                { name: 'conditionDescription', isChecked: true, index:2 },
                { name: 'conditionId', isChecked: true, index:2 },
                { name: 'ecmDescription', isChecked: true, index:2 },
                { name: 'ecuId', isChecked: true, index:2 },
                { name: 'rate', isChecked: true, index:2 },
                { name: 'serialNumber', isChecked: true, index:2 },
                { name: 'unitId', isChecked: true, index:2 },
                { name: 'editColumn', isChecked: true, index:3 }];

  //Pagination
  @ViewChild(MatPaginator) paginator: MatPaginator;

  /**
   * Set the paginator after the view init since this component will
   * be able to query its view for the initialized paginator.
   */
  ngAfterViewInit() {
    if(this.paginator !== undefined){
      this.dataSource.paginator = this.paginator;
    }
  }

  // Selection
  selection = new SelectionModel<IappInventoryDetail>(true, []);

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  openDialog() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    //dialogConfig.autoFocus = true;
    dialogConfig.position = {
      'top': '0',
      'left': '450'
    };
    
    dialogConfig.data = { columns: this.displayedColumns, allColumns: this.allColumns}
    let dialogRef = this.dialog.open(ColumnCustomizeComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(result => {
      this.allColumns = result;
      this.allColumns.forEach(column => this.updateDisplayedColumns(column.name, column.isChecked, column.index));
    });
  }

  updateDisplayedColumns(colName: string, colIsChecked : boolean, colIndex: number){
    const index: number = this.displayedColumns.indexOf(colName);
    
    if (index !== -1 && !colIsChecked) {
      this.displayedColumns.splice(index, 1);
    } else if (index === -1 && colIsChecked) {
      this.displayedColumns.splice(colIndex, 0, colName);
    }       
  }
  

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }
  
  //  updatePopoverContent(inventory: IappInventoryDetail): any[] {
  //    return this.popoverContent = inventory.model;
    
  //  }
  ngOnInit() {
    this.displayedColumns = ['select', 'trendId', 'conditionDescription', 'conditionId', 'ecmDescription', 'ecuId', 'rate', 'serialNumber', 'unitId', 'editColumn'];    
    this._appInventoryService.getAppInventoryDetail1(this.param)
                .subscribe(inventory => {
                  console.log(inventory);
                  this.appInventory = inventory;
                  this.rows = this.appInventory;
                  this.dataSource = new MatTableDataSource(this.appInventory); 
                },
                  error => this.errorMessage = <any>error);
  } 

}
