export interface IappInventoryDetail {
 
    trendId: string;
    conditionDescription: string;
    ecmDescription: string;
    model: string;
    ecuId: string;
    rate: string;
    serialNumber: string;
    unitId: string;
}