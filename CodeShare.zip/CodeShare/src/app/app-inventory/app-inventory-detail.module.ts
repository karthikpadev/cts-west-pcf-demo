import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { PopoverModule } from 'ng2-popover';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { MatTableModule, MatButtonModule, MatDialogModule, MatCheckboxModule, MatSlideToggleModule, MatDividerModule, MatListModule, MatPaginatorModule } from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppInventoryDetailComponent } from './app-inventory-detail.component';
import { AppInventoryDetailService } from './app-inventory-details.service';

@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    PopoverModule,
    NgxDatatableModule,
    MatTableModule, 
    MatButtonModule, 
    MatCheckboxModule,
    MatDialogModule,
    MatSlideToggleModule,
    MatDividerModule,
    MatListModule,
    MatPaginatorModule,
    AppInventoryModule,
    //RouterModule.forChild([
        
    //    { path: 'appinventorydetails/:headerId',
     //     canActivate: [  ],
     //     component: AppInventoryDetailComponent }
   // ])
  ],
  declarations: [
    AppInventoryDetailComponent,
  ],
  providers: []
})
export class AppInventoryModule { }