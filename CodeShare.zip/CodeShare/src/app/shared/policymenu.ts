export interface IappWorkspace {
    name: string;
    menu: Array<string>;
}