import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { PopoverModule } from "ng2-popover";
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { MatTableModule, 
        MatButtonModule, 
        MatCheckboxModule, 
        MatDialogModule, 
        MatDividerModule, 
        MatListModule, 
        MatSlideToggleModule, 
        MatPaginatorModule,
        MatTabsModule,
        MatIconModule,
        MatChipsModule,
        MatFormFieldModule} from '@angular/material';
        
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { AppInventoryComponent } from './app-inventory/app-inventory.component';
import { ConvertToBrPipe } from './shared/convertToBrPipe';
import { ColumnCustomizeComponent } from './column-customize/column-customize.component';
import { AppInventoryModule } from './app-inventory/app-inventory.module';
import { AppInventoryService } from './app-inventory/app-inventory.service';
import { PoliciesComponent } from './policies/policies.component';
import { PoliciesviewComponent } from './policies/policiesview.component';
import { ConfigurationviewComponent } from './policies/configurationview.component';
import { PolicymenuComponent } from './policies/policymenu.component';
import { AppPolicyService } from './shared/policymenu.service';
import { DevicesComponent } from './devices/devices.component';
import { AppInventoryDetailComponent } from './app-inventory/app-inventory-detail.component';

import { AppInventoryDetailService } from './app-inventory/app-inventory-details.service';

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    WelcomeComponent, 
    ConvertToBrPipe,
    ColumnCustomizeComponent,
    PoliciesComponent,
    PoliciesviewComponent,
    ConfigurationviewComponent,
    PolicymenuComponent,
    DevicesComponent
  ],
  exports: [
    PopoverModule,
    NgxDatatableModule,
    MatTableModule, 
    MatButtonModule, 
    MatCheckboxModule,
    MatDialogModule,
    MatSlideToggleModule,
    MatDividerModule,
    MatListModule,
    MatPaginatorModule,
    MatTabsModule,
    MatIconModule],
  imports: [
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    PopoverModule,
    NgxDatatableModule,
    MatTableModule, 
    MatButtonModule, 
    MatCheckboxModule,
    MatDialogModule,
    MatSlideToggleModule,
    MatDividerModule,
    MatListModule,
    MatPaginatorModule,
    MatTabsModule,
    MatIconModule,
    MatChipsModule,
    MatFormFieldModule,
    RouterModule.forRoot([
      //{ path: 'policies/:id', component: PolicymenuComponent, outlet:'leftzone'},
      { path: 'policies', component: PoliciesComponent,
        children: [
          
          { path: '', component: PolicymenuComponent, outlet: 'leftzone'},
          { path: '', component: PoliciesviewComponent},
        //  { path: ':id', component: PolicymenuComponent, outlet: 'leftzone'},
        //  { path: 'policysidemenu/:id', component: PolicymenuComponent, outlet: 'leftzone'},
          { path: 'policysidemenu', component: PolicymenuComponent, outlet: 'leftzone'},
          { path: 'policiesview', component: PoliciesviewComponent},
          { path: 'configurationview', component: ConfigurationviewComponent}
        ]
      },
      { path: 'app-devices', component: DevicesComponent},
      { path: '', redirectTo: 'welcome', pathMatch: 'full'},
      { path: '**', redirectTo: 'welcome', pathMatch: 'full'}
  ]),
  AppInventoryModule
  ],
  providers: [AppInventoryService, AppPolicyService, AppInventoryDetailService],
  bootstrap: [AppComponent],
  entryComponents: [ColumnCustomizeComponent]
})
export class AppModule { }
