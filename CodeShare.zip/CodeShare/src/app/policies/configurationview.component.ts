import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'configurationview',
  templateUrl: './configurationview.component.html',
  styleUrls: ['./configurationview.component.css']
})
export class ConfigurationviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
