import { Component, OnInit, Output, Input, SimpleChanges } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { IappWorkspace } from '../shared/policymenu';
import { AppPolicyService } from '../shared/policymenu.service';

@Component({
  selector: 'policysidemenu',
  templateUrl: './policymenu.component.html',
  styleUrls: ['./policymenu.component.css']
})
export class PolicymenuComponent implements OnInit {

  //@Input() workspaceValue : string;
  showParentFolder : boolean;
  showFirstMenuFolder : boolean;
  showSecondMenuFolder : boolean;
  firstMenuHeader : string;
  firstMenu : IappWorkspace[];
  secondMenu : any[];

  constructor(private router: Router, private route: ActivatedRoute,
              private _appPolicyService: AppPolicyService) {
    route.params.subscribe(params => console.log("side menu id parameter",params['id']));
  }

  ngOnInit() {
    this._appPolicyService.getPolicyWorkspaceMenu()
              .subscribe(menu => {
              console.log(menu);
              this.firstMenu = menu;
      }
    );

  this._appPolicyService.policySubject.subscribe(
    data => {
      console.log('subscribed subject data: ',data);
      for(let menu of this.firstMenu){
        console.log(menu.name.includes(data));
        if(menu.name.includes(data)){
          this.showSecondMenu(menu);
          break;
        }
      }
    }
  );

  this.route.params.subscribe(params => console.log(params));
  this.showParentFolder = true;
  this.showFirstMenuFolder = false;
  this.showSecondMenuFolder = false;
  }

  showFirstMenu() {
    this.showParentFolder = false;
    this.showFirstMenuFolder = true;
  }

  showSecondMenu(firstMenu : any) {
    this.showParentFolder = false;
    this.showFirstMenuFolder = false;
    this.showSecondMenuFolder = true;
    this.firstMenuHeader = firstMenu.name;
    this.secondMenu = firstMenu.menu;
    console.log(this.secondMenu);
  }

  upOneFolder(level : string){
    if("firstMenu" === level){
      this.showFirstMenuFolder = true;
      this.showSecondMenuFolder = false;
    }
  }
}
