import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AppPolicyService } from '../shared/policymenu.service';


@Component({
  selector: 'policies',
  templateUrl: './policies.component.html',
  styleUrls: ['./policies.component.css']
})
export class PoliciesComponent implements OnInit {

  routeLinks : any[];
  activeLinkIndex = -1;
  path : string;
  @Output() sidemenuValue = new EventEmitter<string>();

  constructor(private router: Router, private route: ActivatedRoute,
          private _policyService: AppPolicyService) { 
    this.routeLinks = [
      { "label":"Policies",
        "path" : "policiesview",
        "index": 0,
        "routeParam" : "Policy"
      },
      {
        "label": "Configuration",
        "path" : "configurationview",
        "index": 1,
        "routeParam" : "Configuration"
      }
    ];
  }

  updateSideMenu(routeParam : string){
    //this.sidemenuValue.emit(routeParam);
    console.log('routeparam: ',routeParam);
    this._policyService.setSelectedView(routeParam);
  }

  ngOnInit() {
    /*this.router.navigate([{outlets: {primary: 'policies', policymenuroute:'policysidemenu', policytabroute:'policiesview'}}],
                          {relativeTo: this.route});*/
    this.router.events.subscribe((res) => {
      this.activeLinkIndex = this.routeLinks.indexOf(this.routeLinks.find(tab => tab.path === '.' + this.router.url));
    });
  }

  navigate(routeParam : string){

    this.routeLinks.filter(c => { 
      if(c.routeParam === routeParam){
        this.path = c.path;
      } 
    });
    console.log(this.path);
    //this.router.navigate(['policies/configurationview']);
    this.router.navigate([ {outlets: {primary: "policies/"+this.path, leftzone: ["policies", routeParam]}}], 
      {relativeTo: this.route.parent});

  }

}
