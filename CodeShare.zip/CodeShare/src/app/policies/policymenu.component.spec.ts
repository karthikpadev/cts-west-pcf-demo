import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicymenuComponent } from './policymenu.component';

describe('PolicymenuComponent', () => {
  let component: PolicymenuComponent;
  let fixture: ComponentFixture<PolicymenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PolicymenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicymenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
